<?php

/**
 * Class : HttpSample
 * each method of this class describes a sample usage of a http service
 * before start, please set the prerequisites correctly (such as USERNAME,PASSWORD, & DOMAIN )
 */

class HttpSample {

    // your username (fill it with your username)
    private  $USERNAME = "XXXXX";

    // your password (fill it with your password)
    private  $PASSWORD = "XXXXX";

    // your domain (fill it with your domain - usually: "magfa")
    private  $DOMAIN = "XXXXX";

    // base http url
    private  $BASE_HTTP_URL = "http://messaging.magfa.com/magfaHttpService?";

    private  $ERROR_MAX_VALUE = 1000;
    private $errors;





    /**
     * method : constructor
     * the constructor method of the class
     * @return void
     */
    public function __construct() {
        include_once('errors.php');
        $this->errors = $errors;
        // note : always remember to "urlencode" your data which may contain special characters (like your password)
        $this->PASSWORD = urlencode($this->PASSWORD);
    }






    /**
     * method : enqueueSample
     * this method provides a sample usage of "enqueue" service
     * which you can send Mobile Terminating (MT) messages with it
     * @return void
     */
    public function enqueueSample() {
        $method = 'enqueue'; // name of the service

        $senderNumber = "3000XXX"; // [FILL] sender number ; which is your 3000xxx number
        $recipientNumber = "09XXXXXXXXX"; // [FILL] recipient number; the mobile number which will receive the message (e.g 0912XXXXXXX)

        $message = urlencode("Magfa http-enqueue test"); // [FILL] the content of the message; (in url-encoded format !)
        $udh = ""; // [FILL] udh of the message ; (optional)
        // [FILL] coding of the message (optional)
        // if left blank, system will guess the message coding automatically
        $coding = "";

        $checkingMessageId = ""; // [FILL] checking message id (optional)

        // creating the url based on the information above
        $url = $this->BASE_HTTP_URL .
                "service=" . $method .
                "&username=" . $this->USERNAME . "&password=" . $this->PASSWORD . "&domain=" . $this->DOMAIN .
                "&from=" . $senderNumber . "&to=" . $recipientNumber .
                "&message=" . $message . "&coding=" . $coding . "&udh=" . $udh .
                "&chkmessageid=" . $checkingMessageId;

        // sending the request via http call
        $result = $this->call($url);

        // compare the response with the ERROR_MAX_VALUE
        if ($result <= $this->ERROR_MAX_VALUE) {
            echo "An error occured <br> ";
            echo "Error Code : $result ; Error Title : " . $this->errors[$result]['title'] . ' {' . $this->errors[$result]['desc'] . '}';
        } else {
            echo "Message has been successfully sent ; MessageId : $result";
        }
    }







    /**
     * method : getCreditSample
     * this method provides a sample usage of "getCredit" service
     * @return void
     */
    public function getCreditSample() {
        $method = 'getcredit'; // name of the service

        // creating the url
        $url = $this->BASE_HTTP_URL .
                "service=" . $method .
                "&username=" . $this->USERNAME . "&password=" . $this->PASSWORD . "&domain=" . $this->DOMAIN;

        // sending the request via http call
        $result = $this->call($url);

        // checking the response
        if ($result <= $this->ERROR_MAX_VALUE) {
            echo "An error occured <br> ";
            echo "Error Code : $result ; Error Title : " . $this->errors[$result]['title'] . ' {' . $this->errors[$result]['desc'] . '}';
        } else {
            echo "Your Credit : $result";
        }
    }






    /**
     * method : getMessageIdSample
     * this method provides a sample usage of "getMesasgeId" service
     * @return void
     */
    public function getMessageIdSample() {
        $method = 'getMessageId'; // name of the service

        $checkingMessageId = "XXX"; // [FILL] checking message id

        // creating the url
        $url = $this->BASE_HTTP_URL .
                "service=" . $method .
                "&username=" . $this->USERNAME . "&password=" . $this->PASSWORD . "&domain=" . $this->DOMAIN .
                "&chkmessageid=" . $checkingMessageId;

        // sending the request via http call
        $result = $this->call($url);

        // checking the response
        if ($result <= $this->ERROR_MAX_VALUE) {
            echo "An error occured <br> ";
            echo "Error Code : $result ; Error Title : " . $this->errors[$result]['title'] . ' {' . $this->errors[$result]['desc'] . '}';
        } else {
            echo "Message Id : $result";
        }
    }






    /**
     * method : getMessageStatusSample
     * this method provides a sample usage of "getMessageStatus" service
     * @return void
     */
    public function getMessageStatusSample() {
        $method = 'getMessageStatus'; // name of the service

        $messageId = 'XXXXXXXXX'; // [FILL] message Id (which has been returned in the "enqueue" method ) (e.g : 718570969)

        // creating the url
        $url = $this->BASE_HTTP_URL .
                "service=" . $method .
                "&username=" . $this->USERNAME . "&password=" . $this->PASSWORD . "&domain=" . $this->DOMAIN .
                "&messageid=" . $messageId;

        // sending the request via http call
        $result = $this->call($url);

        // checking the response
        if ($result <= -1) {
            echo "An error occured <br> ";
            echo "Error Code : $result ; Error Title : " . $this->errors[$result]['title'] . '{' . $this->errors[$result]['desc'] . '}';
        } else {
            echo "message's status code : $result";
        }
    }





    
    /**
     * method : getRealMessageStatusSample
     * this method provides a sample usage of "getRealMessageStatus" service
     * @return void
     */
    public function getRealMessageStatusSample() {
        $method = 'getRealMessageStatus'; // name of the service
        $messageId = '718570969'; // [FILL] messageId (which has been returned in the "enqueue" method ) (e.g : 718570969)

        // creating the url
        $url = $this->BASE_HTTP_URL .
                "service=" . $method .
                "&username=" . $this->USERNAME . "&password=" . $this->PASSWORD . "&domain=" . $this->DOMAIN .
                "&messageid=" . $messageId;

        // sending the request via http call
        $result = $this->call($url);

        // checking the response
        if ($result <= -1) {
            echo "An error occured ; ";
            echo "Error Code : $result ; Error Title : " . $this->errors[$result]['title'] . '{' . $this->errors[$result]['desc'] . '}';
        } else {
            echo "message's status code : $result";
        }
    }






    /**
     * method : call
     * this method provides a simple way of calling a url
     * you can also use the curl-based implementation of this method (which has been commented below)
     * @param  String $url the input url
     * @return string      the response
     */
    private function call($url){
        return file_get_contents($url);
    }





    /**
     * method : call
     * this method calls a http url and returns the result
     * it uses curl library inorder to send http request; which means that you should have the php5-curl module installed
     * however, you can use simpler methods such as file_get_contents , etc ...
     * @param  String $url  the input url
     * @return String       the response
     */
    /*
    private function call($url) {
        $curl = curl_init($url);
        curl_setopt($curl,  CURLOPT_HEADER,  0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }
    */


}
