<?php
require("HttpSample.php");

$obj = new HttpSample();
//$obj->enqueueSample();
//$obj->getCreditSample();
//$obj->getMessageIdSample();
//$obj->getMessageStatusSample();
//$obj->getRealMessageStatusSample();

?>