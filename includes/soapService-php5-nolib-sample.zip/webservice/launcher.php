<?php
require("WebServiceSample.php");

$wsObj = new WebServiceSample();
//$wsObj->simpleEnqueueSample();
//$wsObj->enqueueSample();
$wsObj->getAllMessagesSample();
//$wsObj->getAllMessagesWithNumberSample();
//$wsObj->getCreditSample();
//$wsObj->getMessageIdSample();
//$wsObj->getRealMessageStatusesSample();

